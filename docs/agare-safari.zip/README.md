# Agare

A personal Safari Web Extension for sentence highlighting and notes.

**Agare** is a play on 召し上がれ (*meshiagare*) — please enjoy your meal. Mark what you take in while you read.

Six inks (`#fff59e` lemon, `#fa9442` tangerine, `#a3ad00` olive, `#de4500` ember, `#96bfe6` sky, `#bf36e0` violet). A transparency slider. Noted sentences take a deeper underline in the same ink; hover shows the note. The side panel lists **this page only**.

A longer highlight never paints over a shorter one already inside it.

New installs stay off until you turn on **this page** or **this site**, so Agare will not mark every tab you open. Settings can switch that to “every site, pause the ones I don’t want.”

Highlights stay in the extension’s sandboxed `storage.local`. They never leave the machine unless you export a JSON file. That file is how you move them between Macs — AirDrop, a USB stick, iCloud Drive — at no cost.

## Install on Safari (macOS)

1. Unzip `agare-safari.zip`. You should see `manifest.json` at the top of the folder.
2. Install **Xcode** from the Mac App Store (free).
3. Xcode → **File → New → Project → macOS → Safari Web Extension**.
4. Name it **Agare**. Signing: your personal Apple ID team.
5. Replace the generated **Resources** with the extension files (`manifest.json`, `engine.js`, `content.js`, `content.css`, `ui.css`, `background.js`, `icons/`). Leave `docs/` and `.github/` out of Resources.
6. Run the scheme once, then quit the placeholder window.
7. Safari → **Settings → Extensions → Agare**. If it is hidden: **Develop → Allow unsigned extensions**, then enable it.

The toolbar icon is a tempura onigiri with no background. It smiles in colour while Agare is on for the tab you are reading; the same onigiri goes deadpan and grey when highlighting is off for that page. Click it to open the side panel. Select a sentence, pick a colour, and tap the pen in the same popup to write a note. The bin removes a highlight; **Remove note** in the composer clears only the note. Click an existing highlight to recast its colour. Double-click a highlight to open the side panel for that page. Right-click a selection for **Highlight with Agare** or **Add Agare note**.

## Chromium trial

Chrome / Edge / Brave: Extensions → Developer mode → **Load unpacked** → this folder (the files next to `manifest.json`).

## GitHub Pages (the website)

This repo is static. **Pages** hosts `docs/` as a public site. It does **not** run a Node server.

1. Push this folder as the root of a GitHub repo (suggested name: `agare`).
2. GitHub → **Settings → Pages**.
3. Source: **Deploy from a branch**.
4. Branch: `main`, folder: `/docs`.
5. Save. After a minute the site is `https://YOUR-USER.github.io/agare/`.

The Pages site is a landing page and a download. The interactive studio you tried in chat is separate.

## GitHub Releases (the zip)

A Release is how you publish a versioned package people can download.

**Once, in the repo:** Settings → Actions → allow GitHub Actions.

**Each time you ship:**

```bash
git tag v1.0.0
git push origin v1.0.0
```

The workflow `.github/workflows/release.yml` zips the extension (without `docs/` or `.github/`) and attaches `agare-safari.zip` to that Release. The download URL is:

`https://github.com/YOUR-USER/agare/releases/latest/download/agare-safari.zip`

You can also create a Release in the GitHub UI (Releases → Draft a new release → tag `v1.0.0`) and attach the zip by hand.

## Storage

- One settings blob (`lumen.s`): opacity, last pen, and site mode (`all` or `ask`).
- One gate blob (`lumen.g`): page and host on/off flags. A page flag wins over its host; missing flags follow the site mode.
- One compact blob per page (`lumen.p.<hash>`): `{ u: pageKey, h: marks }`.
- A mark is `{ i, c, e, p, s, t, n? }` — colour as `0–5`, 24-character prefix/suffix for restore, note omitted when empty.
- Tracking query parameters are stripped from the page key. Hash fragments are ignored.
- A longer highlight never wraps text already inside a shorter one, so inner ink is not overpainted.

Export writes `Agare-highlights.json` (highlights, opacity, site mode, and on/off rules). Import merges by quote (exact + prefix); it does not upload anywhere. Older `Lumen-highlights.json` files still import.

## Licence

MIT. Written for personal use; share the zip as you like.
